const sgMail = require("@sendgrid/mail");
const express = require("express")
const app = express()
require("dotenv").config()

const bodyParser = require("body-parser")
const cors = require("cors")

app.use(bodyParser.urlencoded({extended : true}))
app.use(bodyParser.json())
app.use(cors())

sgMail.setApiKey('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')

app.post('/send_mail',cors() , (req,res)=>{
    const email = req.body.email
    const message = {
        from: 'monicatasmin06@gmail.com',
        to : email,
        subject: 'Welcome Email:',
        html:'<h1>Welcome to DEV@Deakin</h1><br><h3>Our daily insider</h3>'
    }
    // msg to the terminal if the mail has been sent/failed
        sgMail.send(message, function(error, i){
        if(error){
            res.send(error)
        }else{
            res.json(i)
        }
    });
})

app.get("/",(req,res) => {
    res.json("Welcome to DEAKIN API")
})

app.listen(process.env.PORT || 5000,(req,res) => {
    console.log("Listening on port 5000...")
}) 